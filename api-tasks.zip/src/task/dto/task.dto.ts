export class TaskDto {
    readonly description: string;
    readonly isDone: boolean;
}

