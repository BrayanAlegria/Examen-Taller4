export interface TaskDto {
    description: string;
    isDone: boolean;
}