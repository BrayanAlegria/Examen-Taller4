import { Controller, Post, Req } from '@nestjs/common';
import { Request } from 'express'; // Asumiendo que se está usando express

@Controller('task')
export class TaskController {
    @Post()
    METHODS(@Req() req: Request): string {
        return `method ${req.method}`;
    }
}



